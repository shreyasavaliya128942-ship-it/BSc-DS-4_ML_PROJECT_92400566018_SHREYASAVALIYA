import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler

def load_data(path):
    return pd.read_csv(path)

def handle_missing(df):
    return df.fillna(df.mean(numeric_only=True))

def encode_data(df):
    le = LabelEncoder()
    for col in df.select_dtypes(include=['object']).columns:
        df[col] = le.fit_transform(df[col])
    return df

def scale_data(X):
    scaler = StandardScaler()
    return scaler.fit_transform(X)
