import matplotlib.pyplot as plt
import seaborn as sns

def correlation_matrix(df):
    sns.heatmap(df.corr(), annot=False)
    plt.title("Correlation Matrix")
    plt.show()

def box_plot(df, column):
    sns.boxplot(x=df[column])
    plt.title(f"Box Plot of {column}")
    plt.xlabel(column)
    plt.show()

def scatter_plot(df, col1, col2):
    plt.scatter(df[col1], df[col2])
    plt.show()
