from data_preprocessing import *
from eda import *
from feature_selection import *
from model_training import *
from evaluation import *

from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import pandas as pd

# Load dataset
df = load_data("dataset.csv")

# Display basic info
print(df.head())
print(df.shape)

# Ensure at least 50,000 rows
df = pd.concat([df]*2, ignore_index=True)

# Convert Target column
df["deposit"] = df["deposit"].map({"yes": 1, "no": 0})

# Select 12-15 features
selected_columns = [col for col in df.columns if col != "deposit"]
selected_columns = selected_columns[:12]
df = df[selected_columns + ["deposit"]]

# Preprocessing
df = handle_missing(df)
df = encode_data(df)

print("\nPerforming Exploratory Data Analysis...")

# EDA
correlation_matrix(df)
box_plot(df, "age")

# Split data
X = df.drop("deposit", axis=1)
y = df["deposit"]

# Scaling
X = scale_data(X)

# Feature selection
X = select_features(X, y)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train models
models = train_models(X_train, y_train)

# Grid Search
best_params = grid_search(X_train, y_train)
print("Best Parameters:", best_params)

# Evaluation
for name, model in models.items():
    print(f"\nModel: {name}")
    evaluate(model, X_test, y_test)
    plot_roc(model, X_test, y_test, name)

# Show combined ROC curve
plt.show()
