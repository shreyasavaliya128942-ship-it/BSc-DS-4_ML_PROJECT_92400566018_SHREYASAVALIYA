from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier

def train_models(X_train, y_train):
    models = {}

    models['logistic'] = LogisticRegression(max_iter=1000)
    models['tree'] = DecisionTreeClassifier()
    models['forest'] = RandomForestClassifier()

    for name in models:
        models[name].fit(X_train, y_train)

    return models

def grid_search(X_train, y_train):
    param_grid = {
        'n_estimators': [50, 100],
        'max_depth': [5, 10]
    }

    grid = GridSearchCV(RandomForestClassifier(), param_grid, cv=5)
    grid.fit(X_train, y_train)

    return grid.best_params_
